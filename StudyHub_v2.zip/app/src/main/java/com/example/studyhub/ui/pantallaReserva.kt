package com.example.studyhub.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.time.LocalDate

@Composable
fun PantallaReserva(navController: NavController) {
    val hoy = LocalDate.now()
    var diaSeleccionado by remember { mutableStateOf(hoy) }

    val dias = (0..6).map { hoy.plusDays(it.toLong()) }

    val horasManana = listOf("09:00", "09:30", "10:00", "10:30")
    val horasTarde = listOf("12:00", "13:00", "14:30", "15:00")
    val horasNoche = listOf("17:00", "18:00", "19:00")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "📅 Reserva de Sala",
            style = MaterialTheme.typography.titleMedium
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(dias.size) { index ->
                val dia = dias[index]
                val seleccionado = dia == diaSeleccionado

                Box(
                    modifier = Modifier
                        .width(60.dp)
                        .height(60.dp)
                        .background(
                            if (seleccionado)
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                            else
                                MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { diaSeleccionado = dia },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = dia.dayOfMonth.toString())
                }
            }
        }

        Text(text = "🌅 Mañana")
        HorasDisponibles(horasManana)

        Text(text = "☀️ Tarde")
        HorasDisponibles(horasTarde)

        Text(text = "🌙 Noche")
        HorasDisponibles(horasNoche)

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text("Confirmar reserva")
        }
    }
}

@Composable
fun HorasDisponibles(listaHoras: List<String>) {
    var horaSeleccionada by remember { mutableStateOf<String?>(null) }

    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(listaHoras.size) { index ->
            val hora = listaHoras[index]
            val seleccionada = hora == horaSeleccionada

            Box(
                modifier = Modifier
                    .background(
                        if (seleccionada)
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                        else
                            MaterialTheme.colorScheme.surfaceVariant,
                        RoundedCornerShape(10.dp)
                    )
                    .clickable { horaSeleccionada = hora }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(text = hora)
            }
        }
    }
}
