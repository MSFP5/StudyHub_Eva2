package com.example.studyhub.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

data class SalaEstudio(
    val nombre: String,
    val capacidad: Int
)

@Composable
fun PantallaInicio(navController: NavController) {
    val salas = listOf(
        SalaEstudio("Sala A", 4),
        SalaEstudio("Sala B", 6),
        SalaEstudio("Sala C", 8),
        SalaEstudio("Sala D", 10)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Text(
            text = "Salas de estudio disponibles",
            modifier = Modifier.padding(bottom = 20.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(salas) { sala ->
                TarjetaSala(sala) {
                    navController.navigate("reserva")
                }
            }
        }
    }
}

@Composable
fun TarjetaSala(sala: SalaEstudio, onReservar: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.Start
        ) {
            Text(text = sala.nombre)
            Text(text = "Capacidad: ${sala.capacidad} personas")

            Spacer(modifier = Modifier.height(8.dp))

            Button(onClick = { onReservar() }) {
                Text("Reservar")
            }
        }
    }
}
