package com.example.studyhub.reservas

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_rooms")
data class StudyRoomEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val opensAt: String,
    val closesAt: String,
    val capacity: Int = 4,
    val description: String = ""
)