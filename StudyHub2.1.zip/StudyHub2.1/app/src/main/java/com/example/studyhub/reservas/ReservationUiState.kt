package com.example.studyhub.reservas

sealed class ReservationUiState {

    object Loading : ReservationUiState()

    data class Error(val message: String) : ReservationUiState()

    data class RoomsLoaded(val rooms: List<StudyRoomEntity>) : ReservationUiState()
}