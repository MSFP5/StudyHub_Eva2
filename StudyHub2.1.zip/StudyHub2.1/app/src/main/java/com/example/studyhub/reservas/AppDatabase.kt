package com.example.studyhub.reservas

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [StudyRoomEntity::class, ReservationEntity::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun reservationDao(): ReservationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "studyhub_db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Pre-populate rooms
                            INSTANCE?.let { database ->
                                CoroutineScope(Dispatchers.IO).launch {
                                    val dao = database.reservationDao()
                                    dao.insertRooms(
                                        listOf(
                                            StudyRoomEntity(id = 1, name = "Sala A", opensAt = "08:00", closesAt = "20:00", capacity = 4, description = "Sala de estudio individual."),
                                            StudyRoomEntity(id = 2, name = "Sala B", opensAt = "09:00", closesAt = "21:00", capacity = 6, description = "Sala para grupos pequeños."),
                                            StudyRoomEntity(id = 3, name = "Sala C", opensAt = "08:30", closesAt = "18:30", capacity = 10, description = "Sala con proyector y pizarra."),
                                            StudyRoomEntity(id = 4, name = "Sala D", opensAt = "10:00", closesAt = "22:00", capacity = 2, description = "Sala silenciosa para trabajo concentrado.")
                                        )
                                    )
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}