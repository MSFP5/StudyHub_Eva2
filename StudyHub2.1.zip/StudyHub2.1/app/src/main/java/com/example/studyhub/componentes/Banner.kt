package com.example.studyhub.componentes

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.example.studyhub.R
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource


@Composable
fun Banner(){
    Box(
        modifier = Modifier.padding(horizontal = 16.dp)
            .fillMaxWidth()
            .padding(top = 24.dp),
        contentAlignment = Alignment.BottomCenter
    ){
        Image(
            painter = painterResource(R.drawable.banner1),
            contentDescription = null,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)),
            contentScale = ContentScale.Crop

        )
    }

}