package com.example.studyhub.reservas

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.*

class ReservationsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ReservationRepository = ReservationRepository.getInstance(application)

    suspend fun getRoomById(roomId: Long): StudyRoomEntity? {
        return repository.getRooms().find { it.id == roomId }
    }


    fun createReservation(
        roomId: Long,
        userEmail: String,
        startEpochMs: Long,
        durationMinutes: Long,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val endEpochMs = startEpochMs + durationMinutes * 60 * 1000

            val reservation = ReservationEntity(
                roomId = roomId,
                userEmail = userEmail,
                startEpochMs = startEpochMs,
                endEpochMs = endEpochMs
            )

            repository.tryCreateReservation(reservation)
                .onSuccess { id ->
                    val startZdt = Instant.ofEpochMilli(startEpochMs).atZone(ZoneId.systemDefault())
                    onResult(true, "Reserva creada con éxito (ID: $id) para las ${startZdt.toLocalTime()}.")
                }
                .onFailure { exception ->
                    onResult(false, "Fallo al reservar: ${exception.message}")
                }
        }
    }
}