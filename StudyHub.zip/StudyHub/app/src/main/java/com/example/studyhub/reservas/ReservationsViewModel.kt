package com.example.studyhub.reservas

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.*

sealed class ReservationUiState {
    object Loading : ReservationUiState()
    data class RoomsLoaded(val rooms: List<StudyRoomEntity>) : ReservationUiState()
    data class Error(val message: String) : ReservationUiState()
}

class ReservationsViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = ReservationRepository.getInstance(application.applicationContext)

    private val _uiState = MutableStateFlow<ReservationUiState>(ReservationUiState.Loading)
    val uiState: StateFlow<ReservationUiState> = _uiState

    init {
        loadRooms()
    }

    fun loadRooms() {
        viewModelScope.launch {
            try {
                val rooms = repo.getRooms()
                _uiState.value = ReservationUiState.RoomsLoaded(rooms)
            } catch (e: Exception) {
                _uiState.value = ReservationUiState.Error(e.message ?: "Error")
            }
        }
    }

    fun createReservation(
        roomId: Long,
        userEmail: String,
        startEpochMs: Long,
        durationMinutes: Long,
        onResult: (success: Boolean, message: String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val endEpoch = startEpochMs + durationMinutes * 60_000
                // Basic sanity checks
                val now = Instant.now().toEpochMilli()
                if (startEpochMs < now) { onResult(false, "No puedes reservar en el pasado"); return@launch }
                val year2100 = LocalDate.of(2100,1,1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                if (startEpochMs > year2100) { onResult(false, "Fecha demasiado lejana"); return@launch }

                val reservation = ReservationEntity(
                    roomId = roomId,
                    userEmail = userEmail,
                    startEpochMs = startEpochMs,
                    endEpochMs = endEpoch
                )
                val result = repo.tryCreateReservation(reservation)
                if (result.isSuccess) onResult(true, "Reservado correctamente") else onResult(false, "La franja ya está reservada")
            } catch (e: Exception) {
                onResult(false, e.message ?: "Error")
            }
        }
    }

    suspend fun getReservationsForRoomBetween(roomId: Long, from: Long, to: Long) = repo.getReservationsForRoomBetween(roomId, from, to)
}
