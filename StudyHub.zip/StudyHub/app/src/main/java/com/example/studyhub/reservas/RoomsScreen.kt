package com.example.studyhub.reservas

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.widget.DatePicker
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.*
import java.util.*

@Composable
fun RoomsScreen(
    onOpenReservation: (StudyRoomEntity) -> Unit,
    viewModel: ReservationsViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    when (uiState) {
        is ReservationUiState.Loading -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        is ReservationUiState.Error -> Text(text = (uiState as ReservationUiState.Error).message)
        is ReservationUiState.RoomsLoaded -> {
            val rooms = (uiState as ReservationUiState.RoomsLoaded).rooms
            LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                items(rooms) { room ->
                    Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = room.name, style = MaterialTheme.typography.titleMedium)
                                Text(text = "Capacidad: ${room.capacity}")
                                Text(text = "Horario: ${room.opensAt} - ${room.closesAt}")
                            }
                            Button(onClick = { onOpenReservation(room) }) { Text("Reservar") }
                        }
                    }
                }
            }
        }
    }
}