package com.example.studyhub.reservas

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_rooms")
data class StudyRoomEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val capacity: Int,
    val opensAt: String, // "HH:mm"
    val closesAt: String // "HH:mm"
)