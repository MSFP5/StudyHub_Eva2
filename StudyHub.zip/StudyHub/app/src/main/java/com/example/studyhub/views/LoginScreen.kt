package com.example.studyhub.views

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.studyhub.R
import com.example.studyhub.componentes.CButton
import com.example.studyhub.ui.theme.AlegreyaFontFamily
import com.example.studyhub.ui.theme.AlegreyaSansFontFamily
import com.example.studyhub.componentes.CTextField
import com.example.studyhub.componentes.DontHaveAccount
import com.example.studyhub.viewModels.LoginViewModel
import com.example.studyhub.viewModels.LoginViewModelFactory
import android.content.Context

@Composable
fun LoginScreen(navController: NavHostController) {

    val context = LocalContext.current
    val viewModel: LoginViewModel = viewModel(factory = LoginViewModelFactory(context))

    val state = viewModel.state.collectAsState().value
    val errors = viewModel.errors.collectAsState().value

    Surface(
        color = Color(0xFF253334),
        modifier = Modifier.fillMaxSize()
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logos),
                    contentDescription = null,
                    modifier = Modifier
                        .padding(top = 60.dp)
                        .height(80.dp)
                        .align(Alignment.Start)
                        .offset(x = (-20).dp)
                        .padding(bottom = 24.dp)
                )

                Text(
                    text = "Iniciar Sesión",
                    style = TextStyle(
                        fontSize = 28.sp,
                        fontFamily = AlegreyaFontFamily,
                        fontWeight = FontWeight(500),
                        color = Color.White
                    ),
                    modifier = Modifier.align(Alignment.Start)
                )

                Text(
                    "Inicia sesión ahora para acceder a nuestras múltiples salas de estudio, reuniones y conferencias.",
                    style = TextStyle(
                        fontSize = 20.sp,
                        fontFamily = AlegreyaSansFontFamily,
                        color = Color(0xB2FFFFFF)
                    ),
                    modifier = Modifier
                        .align(Alignment.Start)
                        .padding(top = 16.dp)
                        .padding(bottom = 24.dp)
                )

                CTextField(
                    hint = "Gmail",
                    value = state.email,
                    onValueChange = viewModel::onEmailChange,
                    isError = errors.emailError != null,
                    errorText = errors.emailError
                )

                Spacer(modifier = Modifier.height(12.dp))

                CTextField(
                    hint = "Contraseña",
                    value = state.contrasena,
                    onValueChange = viewModel::onContrasenaChange,
                    isPassword = true,
                    isError = errors.contrasenaError != null,
                    errorText = errors.contrasenaError
                )

                Spacer(modifier = Modifier.height(24.dp))

                if (errors.globalError != null) {
                    Text(
                        text = errors.globalError!!,
                        style = TextStyle(
                            fontSize = 16.sp,
                            fontFamily = AlegreyaSansFontFamily,
                            color = Color.Red,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
                    )
                }

                CButton(
                    text = if (state.isLoading) "Iniciando..." else "Iniciar Sesión",
                    enabled = !state.isLoading,
                    onClick = {
                        viewModel.onLoginClick {
                            val appContext = context.applicationContext
                            val prefs = appContext.getSharedPreferences("studyhub_prefs", Context.MODE_PRIVATE)
                            prefs.edit().putString("user_email", state.email).apply()

                            navController.navigate("reservation") {
                                popUpTo(navController.graph.startDestinationId) {
                                    inclusive = true
                                }
                            }
                        }
                    }
                )

                DontHaveAccount(onSignupTap = { navController.navigate("signup") })
            }
        }
    }
}
