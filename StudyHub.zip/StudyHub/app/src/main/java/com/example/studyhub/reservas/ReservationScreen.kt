package com.example.studyhub.reservas

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.*
import java.util.*

@Composable
fun ReservationScreen(
    room: StudyRoomEntity,
    onBack: () -> Unit,
    viewModel: ReservationsViewModel = viewModel()
) {
    val context = LocalContext.current
    var selectedDate by remember { mutableStateOf<LocalDate?>(null) }
    var selectedStartLocalTime by remember { mutableStateOf<LocalTime?>(null) }
    var durationHours by remember { mutableStateOf(1) }
    var message by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Text("<-") }
            Text(text = "Reservar: ${room.name}", style = MaterialTheme.typography.titleLarge)
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(onClick = {
            val now = LocalDate.now()
            val datePicker = DatePickerDialog(
                context,
                { _: android.widget.DatePicker, year: Int, month: Int, dayOfMonth: Int ->
                    selectedDate = LocalDate.of(year, month + 1, dayOfMonth)
                },
                now.year, now.monthValue - 1, now.dayOfMonth
            )
            val min = Calendar.getInstance()
            datePicker.datePicker.minDate = min.timeInMillis
            val maxCal = Calendar.getInstance().apply { set(2100, Calendar.DECEMBER, 31) }
            datePicker.datePicker.maxDate = maxCal.timeInMillis
            datePicker.show()
        }) { Text(text = selectedDate?.toString() ?: "Elegir fecha") }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedButton(onClick = {
            val now = LocalTime.now()
            val tpd = TimePickerDialog(
                context,
                { _, hourOfDay, minute -> selectedStartLocalTime = LocalTime.of(hourOfDay, minute) },
                now.hour, now.minute, true
            )
            tpd.show()
        }) { Text(text = selectedStartLocalTime?.toString() ?: "Elegir hora de inicio") }

        Spacer(modifier = Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Duración (horas):")
            Spacer(modifier = Modifier.width(8.dp))
            NumberPicker(value = durationHours, onValueChange = { durationHours = it }, min = 1, max = 8)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            if (selectedDate == null || selectedStartLocalTime == null) {
                message = "Selecciona fecha y hora"
                return@Button
            }

            val startZdt = ZonedDateTime.of(selectedDate, selectedStartLocalTime, ZoneId.systemDefault())
            val startEpoch = startZdt.toInstant().toEpochMilli()
            val durationMinutes = durationHours * 60L
            val opens = LocalTime.parse(room.opensAt)
            val closes = LocalTime.parse(room.closesAt)
            val endLocalTime = selectedStartLocalTime!!.plusHours(durationHours.toLong())

            if (selectedStartLocalTime!!.isBefore(opens) || endLocalTime.isAfter(closes)) {
                message = "Horario fuera de disponibilidad de la sala"
                return@Button
            }

            val prefs = context.getSharedPreferences("studyhub_prefs", Context.MODE_PRIVATE)
            val userEmail = prefs.getString("user_email", null) ?: "guest@local"

            viewModel.createReservation(room.id, userEmail, startEpoch, durationMinutes) { success, msg ->
                message = msg
            }
        }) {
            Text("Confirmar reserva")
        }

        Spacer(modifier = Modifier.height(12.dp))
        message?.let { Text(it) }
    }
}

@Composable
fun NumberPicker(value: Int, onValueChange: (Int) -> Unit, min: Int = 1, max: Int = 8) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Button(onClick = { if (value > min) onValueChange(value - 1) }) { Text("-") }
        Spacer(modifier = Modifier.width(12.dp))
        Text(text = value.toString())
        Spacer(modifier = Modifier.width(12.dp))
        Button(onClick = { if (value < max) onValueChange(value + 1) }) { Text("+") }
    }
}
