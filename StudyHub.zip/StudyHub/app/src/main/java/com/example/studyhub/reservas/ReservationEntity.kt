package com.example.studyhub.reservas

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reservations")
data class ReservationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val roomId: Long,
    val userEmail: String,
    val startEpochMs: Long,
    val endEpochMs: Long,
    val createdAtMs: Long = System.currentTimeMillis()
)