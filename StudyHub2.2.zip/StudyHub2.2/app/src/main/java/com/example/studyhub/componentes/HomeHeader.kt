package com.example.studyhub.componentes

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.NavigationBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.colorResource
import com.example.studyhub.R
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Icon
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.NavigationBarItem
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.Image
import com.example.studyhub.ui.theme.AlegreyaSansFontFamily
import androidx.compose.material.icons.filled.Remove

@Composable
fun HomeHeader(){
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, top = 16.dp, end = 24.dp),
        verticalAlignment = Alignment.CenterVertically
    ){
        Column (modifier = Modifier
            .weight(1f)
            .padding(horizontal = 16.dp)
        ){
            Text(
                text = "¡Bienvedido!",
                fontSize = 18.sp,
                color = Color.Black,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Reserva la sala de tus sueños, ¡ya!",
                color = Color.Black,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        Image(
            painter = painterResource(id = R.drawable.btn_4),
            contentDescription = null,
            modifier = Modifier.size(20.dp)
        )
    }
}


