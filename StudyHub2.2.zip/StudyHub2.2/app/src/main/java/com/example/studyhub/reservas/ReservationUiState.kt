package com.example.studyhub.reservas

import android.graphics.Bitmap

sealed class ReservationUiState {

    object Loading : ReservationUiState()

    data class Error(val message: String) : ReservationUiState()

    data class RoomsLoaded(val rooms: List<StudyRoomEntity>) : ReservationUiState()

    data class ReservationCreated(
        val message: String,
        val qrBitmap: Bitmap
    ) : ReservationUiState()
}
