package com.example.studyhub.reservas

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.*
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

class ReservationsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ReservationRepository = ReservationRepository.getInstance(application)

    private val _uiState = MutableStateFlow<ReservationUiState>(ReservationUiState.Loading)
    val uiState: StateFlow<ReservationUiState> = _uiState

    suspend fun getRoomById(roomId: Long): StudyRoomEntity? {
        return repository.getRooms().find { it.id == roomId }
    }

    private fun generateQr(content: String): Bitmap {
        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, 512, 512)
        val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.RGB_565)

        for (x in 0 until 512) {
            for (y in 0 until 512) {
                bmp.setPixel(x, y, if (bitMatrix.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }
        return bmp
    }

    fun createReservation(
        roomId: Long,
        userEmail: String,
        startEpochMs: Long,
        durationMinutes: Long,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val endEpochMs = startEpochMs + durationMinutes * 60 * 1000

            val reservation = ReservationEntity(
                roomId = roomId,
                userEmail = userEmail,
                startEpochMs = startEpochMs,
                endEpochMs = endEpochMs
            )

            repository.tryCreateReservation(reservation)
                .onSuccess { id ->

                    val content = "RESERVA#$id|ROOM=$roomId|EMAIL=$userEmail|START=$startEpochMs|END=$endEpochMs"
                    val qr = generateQr(content)

                    val startZdt = Instant.ofEpochMilli(startEpochMs).atZone(ZoneId.systemDefault())
                    val msg = "Reserva creada con éxito (ID: $id) para las ${startZdt.toLocalTime()}."

                    onResult(true, msg)

                    _uiState.value = ReservationUiState.ReservationCreated(msg, qr)
                }
                .onFailure { exception ->
                    val error = "Fallo al reservar: ${exception.message}"
                    onResult(false, error)
                    _uiState.value = ReservationUiState.Error(error)
                }
        }
    }
}
