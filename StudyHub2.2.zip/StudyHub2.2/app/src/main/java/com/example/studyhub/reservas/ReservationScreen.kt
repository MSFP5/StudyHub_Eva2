package com.example.studyhub.reservas

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Schedule
import java.time.*
import java.util.*
import androidx.navigation.NavHostController
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun ReservationScreen(
    navController: NavHostController,
    roomId: Long,
    viewModel: ReservationsViewModel = viewModel()
) {
    val context = LocalContext.current
    var selectedDate by remember { mutableStateOf<LocalDate?>(null) }
    var selectedStartLocalTime by remember { mutableStateOf<LocalTime?>(null) }
    var durationHours by remember { mutableStateOf(1) }
    var message by remember { mutableStateOf<String?>(null) }
    var roomEntity by remember { mutableStateOf<StudyRoomEntity?>(null) }
    val coroutineScope = rememberCoroutineScope()

    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(roomId) {
        coroutineScope.launch {
            roomEntity = viewModel.getRoomById(roomId)
        }
    }

    val room = roomEntity
    if (room == null) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("Cargando Sala...") },
                    navigationIcon = {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Atrás")
                        }
                    }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                if (roomEntity == null) {
                    CircularProgressIndicator()
                } else {
                    Text(
                        "Error: Sala con ID $roomId no encontrada.",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
        return
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Reservar: ${room.name}") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Atrás")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = "Horario disponible: ${room.opensAt} - ${room.closesAt}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            ElevatedCard(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                onClick = { showDatePicker(context, selectedDate) { picked -> selectedDate = picked } }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.DateRange, contentDescription = "Fecha", modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = selectedDate?.toString() ?: "Seleccionar Fecha",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            ElevatedCard(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                onClick = { showTimePicker(context, selectedStartLocalTime) { picked -> selectedStartLocalTime = picked } }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Schedule, contentDescription = "Hora", modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = selectedStartLocalTime?.toString() ?: "Seleccionar Hora de Inicio",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Duración (horas):", style = MaterialTheme.typography.titleMedium)
                NumberPicker(value = durationHours, onValueChange = { durationHours = it })
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    if (selectedDate == null || selectedStartLocalTime == null) {
                        message = "Selecciona fecha y hora"
                        return@Button
                    }

                    val startZdt = ZonedDateTime.of(selectedDate, selectedStartLocalTime, ZoneId.systemDefault())
                    val startEpoch = startZdt.toInstant().toEpochMilli()
                    val durationMinutes = durationHours * 60L

                    val opens = LocalTime.parse(room.opensAt)
                    val closes = LocalTime.parse(room.closesAt)
                    val endLocalTime = selectedStartLocalTime!!.plusHours(durationHours.toLong())

                    if (selectedStartLocalTime!!.isBefore(opens) || endLocalTime.isAfter(closes)) {
                        message = "Horario fuera de disponibilidad de la sala"
                        return@Button
                    }

                    val prefs = context.getSharedPreferences("studyhub_prefs", Context.MODE_PRIVATE)
                    val userEmail = prefs.getString("user_email", null) ?: "guest@local"

                    viewModel.createReservation(room.id, userEmail, startEpoch, durationMinutes) { _, msg ->
                        message = msg
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("Confirmar reserva", style = MaterialTheme.typography.titleMedium)
            }

            Spacer(modifier = Modifier.height(12.dp))

            message?.let {
                Text(
                    it,
                    color = if (it.contains("éxito") || it.contains("creada"))
                        MaterialTheme.colorScheme.primary
                    else
                        MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            when (uiState) {
                is ReservationUiState.ReservationCreated -> {
                    Spacer(modifier = Modifier.height(20.dp))
                    val qrBitmap = (uiState as ReservationUiState.ReservationCreated).qrBitmap
                    Image(
                        bitmap = qrBitmap.asImageBitmap(),
                        contentDescription = "Código QR",
                        modifier = Modifier.size(200.dp)
                    )
                }
                else -> {}
            }
        }
    }
}

@Composable
fun NumberPicker(value: Int, onValueChange: (Int) -> Unit, min: Int = 1, max: Int = 8) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        FilledTonalButton(
            onClick = { if (value > min) onValueChange(value - 1) },
            shape = RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp),
            modifier = Modifier.size(40.dp)
        ) { Icon(Icons.Default.Remove, contentDescription = "Restar") }

        Surface(
            modifier = Modifier.width(48.dp).height(40.dp),
            shape = RoundedCornerShape(0.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(value.toString(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        }

        FilledTonalButton(
            onClick = { if (value < max) onValueChange(value + 1) },
            shape = RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp),
            modifier = Modifier.size(40.dp)
        ) { Icon(Icons.Default.Add, contentDescription = "Sumar") }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
private fun showDatePicker(
    context: Context,
    initialDate: LocalDate?,
    onDateSelected: (LocalDate) -> Unit
) {
    val now = initialDate ?: LocalDate.now()
    val datePicker = DatePickerDialog(
        context,
        { _: android.widget.DatePicker, year, month, day ->
            onDateSelected(LocalDate.of(year, month + 1, day))
        },
        now.year, now.monthValue - 1, now.dayOfMonth
    )
    val min = Calendar.getInstance()
    datePicker.datePicker.minDate = min.timeInMillis
    val maxCal = Calendar.getInstance().apply { set(2100, Calendar.DECEMBER, 31) }
    datePicker.datePicker.maxDate = maxCal.timeInMillis
    datePicker.show()
}

@RequiresApi(Build.VERSION_CODES.O)
private fun showTimePicker(
    context: Context,
    initialTime: LocalTime?,
    onTimeSelected: (LocalTime) -> Unit
) {
    val now = initialTime ?: LocalTime.now()
    val tpd = TimePickerDialog(
        context,
        { _, hour, minute -> onTimeSelected(LocalTime.of(hour, minute)) },
        now.hour, now.minute, true
    )
    tpd.show()
}
