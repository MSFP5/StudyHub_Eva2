package com.example.studyhub

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.studyhub.ui.theme.StudyHubTheme
import com.example.studyhub.views.HomeScreen
import com.example.studyhub.views.LoginScreen
import com.example.studyhub.views.SignupScreen
import com.example.studyhub.views.WelcomeScreen
import com.example.studyhub.reservas.ReservationScreen
import androidx.navigation.navArgument
import androidx.navigation.NavType

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StudyHubTheme {
                NavigationView(this)
            }
        }
    }
}

@Composable
fun NavigationView(context: Context) {
    val navController = rememberNavController()
    val prefs = context.getSharedPreferences("studyhub_prefs", Context.MODE_PRIVATE)
    val savedEmail = prefs.getString("user_email", null)
    val startDestination = remember { mutableStateOf("welcome") }

    val initialRoute = remember {
        if (savedEmail != null) "home" else "welcome"
    }

    NavHost(
        navController = navController,
        startDestination = "welcome"
    ) {
        composable("welcome") { WelcomeScreen(navController) }
        composable("login") { LoginScreen(navController) }
        composable("signup") { SignupScreen(navController) }
        composable("home") { HomeScreen(navController) }

        composable(
            route = "Reservation/{roomId}",
            arguments = listOf(navArgument("roomId") { type = NavType.LongType })
        )
        { backStackEntry ->
            val roomId = backStackEntry.arguments?.getLong("roomId")
            if (roomId != null && roomId != 0L) {
                ReservationScreen(navController, roomId = roomId)
            }
        }

    }
}
