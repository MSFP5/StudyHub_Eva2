package com.example.studyhub.reservas

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Instant

class ReservationRepository private constructor(private val db: AppDatabase) {

    private val dao = db.reservationDao()

    suspend fun getRooms(): List<StudyRoomEntity> = withContext(Dispatchers.IO) {
        dao.getAllRooms()
    }

    suspend fun tryCreateReservation(reservation: ReservationEntity): Result<Long> = withContext(Dispatchers.IO) {

        val overlaps = dao.getOverlapping(reservation.roomId, reservation.startEpochMs, reservation.endEpochMs)
        return@withContext if (overlaps.isEmpty()) {
            val id = dao.insertReservation(reservation)
            Result.success(id)
        } else {
            Result.failure(Exception("Overlap detected"))
        }
    }

    suspend fun getReservationsForRoomBetween(roomId: Long, from: Long, to: Long) = withContext(Dispatchers.IO) {
        dao.getReservationsForRoomBetween(roomId, from, to)
    }

    suspend fun generateQr(reservationId: Long): String = withContext(Dispatchers.IO) {

        return@withContext "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=reservation-$reservationId"
    }

    companion object {
        @Volatile
        private var INSTANCE: ReservationRepository? = null

        fun getInstance(context: Context): ReservationRepository {
            return INSTANCE ?: synchronized(this) {
                val repo = ReservationRepository(AppDatabase.getInstance(context))
                INSTANCE = repo
                repo
            }
        }
    }
}
