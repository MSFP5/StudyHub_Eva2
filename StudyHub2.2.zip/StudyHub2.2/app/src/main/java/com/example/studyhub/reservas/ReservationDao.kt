package com.example.studyhub.reservas

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface ReservationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRooms(rooms: List<StudyRoomEntity>)

    @Query("SELECT * FROM study_rooms ORDER BY id")
    suspend fun getAllRooms(): List<StudyRoomEntity>

    @Query("SELECT * FROM reservations WHERE roomId = :roomId AND NOT (endEpochMs <= :start OR startEpochMs >= :end)")
    suspend fun getOverlapping(roomId: Long, start: Long, end: Long): List<ReservationEntity>

    @Insert
    suspend fun insertReservation(reservation: ReservationEntity): Long

    @Query("SELECT * FROM reservations WHERE roomId = :roomId AND startEpochMs >= :from AND startEpochMs < :to ORDER BY startEpochMs")
    suspend fun getReservationsForRoomBetween(roomId: Long, from: Long, to: Long): List<ReservationEntity>
}