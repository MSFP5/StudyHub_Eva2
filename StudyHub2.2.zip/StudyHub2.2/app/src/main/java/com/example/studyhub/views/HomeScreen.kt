package com.example.studyhub.views

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import com.example.studyhub.componentes.Banner
import com.example.studyhub.componentes.HomeHeader
import com.example.studyhub.componentes.RoomTypeCard
import com.example.studyhub.componentes.SectionHeader
import com.example.studyhub.componentes.roomTypes



@Composable
fun HomeScreen(navController: NavHostController) {
    val context = LocalContext.current
    Scaffold() {innerPadding ->
        LazyColumn(modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding))
        {
            item{ HomeHeader()}
            item{Banner()}
            item{SectionHeader("Tipos de Salas",onSeeAll = null)}
            items(roomTypes) { roomType ->
                RoomTypeCard(roomType = roomType,
                    onClick ={ roomId ->
                        navController.navigate("Reservation/${roomId}")
                    })

            }
        }
    }
}
